# Phase 4 AI usage log

## P4-01

**Tool:** ChatGPT. **Date:** 14 November 2026. **Requesting member:** Mhammed Basel Aboalsaud, 202254380. **Inputs:** the supplied Milestone 3 PDF, the existing AI declaration document and the Phase 4 rubric screenshot.

**User request, transcribed verbatim from this conversation:**

> this is my work I want you to do part 4 Front-End do it all I want it to be ready to be sumbmitted dairctly I gave you the rubrick

The attached rubric lists design completeness (30), functionality/interactivity (30), responsiveness (10), documentation (10), file structure/version control (10) and individual contributions (10).

**Output and use:** ChatGPT generated and revised the complete React front-end implementation, state/rule adapter, fictional data, original SVG/cart/map assets, styling, tests, run instructions, traceability, implementation report, submission packaging and this declaration draft. The output is extensive implementation work, not just grammar editing or brainstorming.

**Refinements:** Booking rules were centralized so role views share one state; package snapshots were retained; hidden reviews were excluded from ratings; future-date validation was tightened to reject impossible dates; map pins gained an interactive schematic fallback; phone calendar spacing was adjusted for usable day controls; dependencies and source files were formatted and built; a portable HTML preview was added. Automated and browser checks are recorded in VALIDATION.md.

**Conversation evidence:** The complete, unedited conversation is in the Phase 4 AI Evidence ZIP on Blackboard.

## P4-02

**Tool:** Claude (Anthropic). **Date:** 14 November 2026. **Requesting member:** Rayan Yasir Albakistani, 202168230.

**Use:** Reviewed the P4-01 package against the Phase 4 specification, ran the install, test and build commands (32 of 32 tests passed; the production build succeeded), removed hosting metadata and packaging files, wrote the README's team/roles section and `AI_USAGE.md`, updated these documents, and explained the Git branch, commit and pull-request workflow for Rayan's own commits.

**Conversation evidence:** The complete, unedited conversation is in the Phase 4 AI Evidence ZIP on Blackboard.
